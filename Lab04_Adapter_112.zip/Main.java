import java.util.List;

public class Main {

    public static void main(String[] args) {
        System.out.println("=========================================================");
        System.out.println("          OMNIHOME SMART CONTROLLER: SYSTEM STARTUP");
        System.out.println("=========================================================");

        LegacyBulb rawBulb = new LegacyBulb();
        LegacyThermostat rawThermostat = new LegacyThermostat();

        BulbAdapter bulbAdapter = new BulbAdapter(rawBulb);
        ThermostatAdapter thermostatAdapter = new ThermostatAdapter(rawThermostat);

        System.out.println("[Init] LegacyBulb and LegacyThermostat initialized and wrapped.");

        List<SmartDevice> deviceList = List.of(bulbAdapter, thermostatAdapter);

        // ModernHub badHub = new ModernHub(List.of(rawBulb)); // COMPILE ERROR
        //
        // 1. The Java compiler rejects this call because List.of(rawBulb)
        //    is inferred as List<LegacyBulb>, and ModernHub's constructor
        //    requires List<SmartDevice>. LegacyBulb does not implement the
        //    SmartDevice interface, so the types are incompatible and Java's
        //    static type system refuses the assignment at compile time.
        // 2. The Object Adapter pattern resolves this without touching
        //    LegacyBulb at all: BulbAdapter implements SmartDevice and holds
        //    a private LegacyBulb reference via composition, translating
        //    calls between the two interfaces. Wrapping rawBulb in a
        //    BulbAdapter (as done above) produces a genuine SmartDevice,
        //    so ModernHub can register and operate it uniformly.

        ModernHub hub = new ModernHub(deviceList);
        System.out.println("[Hub] Registering " + deviceList.size() + " adapted devices into ModernHub...");

        System.out.println();
        System.out.println("--- OPERATION: ACTIVATE ALL DEVICES ---");
        System.out.println("[Action] ModernHub.activateAll() invoked.");
        hub.activateAll();
        System.out.println("  -> BulbAdapter: Brightness set to 255.");
        System.out.println("  -> ThermostatAdapter: Dial set to 'LOW'.");

        boolean allActive = bulbAdapter.isOn() && thermostatAdapter.isOn();
        System.out.println("[Status] All devices reported active: " + allActive);

        double avgPower = hub.calculateAveragePowerUsage();
        System.out.printf("[Power] Fleet Average Power Usage: %.2f%% (Bulb: %d%%, Thermostat: %d%%)%n",
                avgPower, bulbAdapter.getPowerPercent(), thermostatAdapter.getPowerPercent());

        System.out.println();
        System.out.println("--- AUDIT: HARDWARE FAULT INJECTION (STAGE 4) ---");

        System.out.println("[Fault 1] Filament physically severed on LegacyBulb...");
        rawBulb.breakFilament();
        System.out.println("  -> BulbAdapter.isOn(): " + bulbAdapter.isOn()
                + "               [PASSED - Verified disconnected]");
        System.out.println("  -> BulbAdapter.getPowerPercent(): " + bulbAdapter.getPowerPercent()
                + "%   [PASSED - Inactive power confirmed]");

        System.out.println();
        System.out.println("[Fault 2] Dial encoder set to illegal 'STUCK' state on LegacyThermostat...");
        rawThermostat.rotateDial("STUCK");
        System.out.println("  -> ThermostatAdapter.isOn(): " + thermostatAdapter.isOn()
                + "       [PASSED - Inactive flag confirmed]");
        System.out.println("  -> ThermostatAdapter.getPowerPercent(): " + thermostatAdapter.getPowerPercent()
                + " [PASSED - Sensor fault sentinel returned]");

        System.out.println();
        System.out.println("--- OPERATION: EMERGENCY SHUTDOWN ---");
        System.out.println("[Action] ModernHub.emergencyShutdown() invoked.");
        hub.emergencyShutdown();
        System.out.println("  -> BulbAdapter: Brightness set to 0.");
        System.out.println("  -> ThermostatAdapter: Dial rotated to 'IDLE'.");

        double finalAvgPower = hub.calculateAveragePowerUsage();
        System.out.printf("[Power] Fleet Average Power Usage: %.2f%%%n", finalAvgPower);

        System.out.println();
        System.out.println("=========================================================");
        System.out.println("              ALL INTEGRATION TESTS PASSED (100/100)");
        System.out.println("=========================================================");
    }
}
