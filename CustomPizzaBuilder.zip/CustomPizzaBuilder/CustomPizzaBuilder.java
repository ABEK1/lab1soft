public class CustomPizzaBuilder {
    public static void main(String[] args) {
        Pizza pizza = new Pineapple(new Olives(new Cheese(new PlainPizza())));

        System.out.println("Pizza: " + pizza.getDescription());
        System.out.println("Total cost: $" + pizza.getCost());
    }
}
