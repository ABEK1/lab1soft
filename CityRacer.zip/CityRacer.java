public class CityRacer {
    public static void main(String[] args) {
        Player player = new Player(new Walking());
        player.move();

        player.setStrategy(new Skateboarding());
        player.move();

        player.setStrategy(new Jetpack());
        player.move();
    }
}
