public class Walking implements MovementStrategy {
    public void move() {
        System.out.println("Walking: 5 km/h");
    }
}
