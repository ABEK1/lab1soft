public class Skateboarding implements MovementStrategy {
    public void move() {
        System.out.println("Skateboarding: 15 km/h");
    }
}
