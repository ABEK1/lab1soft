public class Jetpack implements MovementStrategy {
    public void move() {
        System.out.println("Jetpack: 60 km/h");
    }
}
