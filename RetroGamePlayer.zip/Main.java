public class Main {
    public static void main(String[] args) {
        ModernConsole console = new CartridgeAdapter(new RetroCartridge());
        console.playDigital();
    }
}
